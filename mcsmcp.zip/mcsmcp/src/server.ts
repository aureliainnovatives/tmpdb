import express, { Request, Response } from "express";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";

const server = new McpServer({
  name: "ey-knowledge-base",
  version: "1.0.0",
});

// EY Knowledge Base Tools
const searchMethodology = server.tool(
  "search-methodology",
  "Search EY methodologies by topic and service line",
  {
    topic: z.string().describe("The methodology topic to search for (e.g., 'digital transformation', 'risk management')"),
    service_line: z.string().optional().describe("EY service line: Assurance, Tax, Strategy, or Consulting")
  },
  async (params: { topic: string; service_line?: string }) => {
    // Extract parameters with safe handling
    const topic = params.topic || "";
    const service_line = params.service_line || "";
    
    const methodologies: any = {
      "digital transformation": {
        "Assurance": "EY Digital Audit Methodology v2.1 - Automated testing frameworks for digital environments, continuous auditing procedures, and risk assessment for cloud-based systems.",
        "Consulting": "EY Digital Strategy Framework - 5-phase transformation approach including current state assessment, future state design, roadmap development, and change management."
      },
      "risk management": {
        "Assurance": "EY Risk Assessment Framework - Comprehensive risk identification, measurement, and monitoring procedures aligned with COSO and ISO 31000 standards.",
        "Consulting": "EY Enterprise Risk Management - Strategic risk integration methodology for board-level risk oversight and operational risk management."
      }
    };
    
    let result = "No methodology found";
    
    if (topic && topic.trim() !== "") {
      const topicLower = topic.toLowerCase().trim();
      if (methodologies[topicLower]) {
        if (service_line && service_line.trim() !== "" && methodologies[topicLower][service_line]) {
          result = methodologies[topicLower][service_line];
        } else {
          const availableLines = Object.keys(methodologies[topicLower]);
          result = `Found methodology for "${topic}". Available service lines: ${availableLines.join(', ')}. Please specify a service line.`;
        }
      } else {
        const availableTopics = Object.keys(methodologies);
        result = `Topic "${topic}" not found. Available topics: ${availableTopics.join(', ')}`;
      }
    } else {
      const availableTopics = Object.keys(methodologies);
      result = `Please provide a topic. Available topics: ${availableTopics.join(', ')}`;
    }
    
    return {
      content: [
        {
          type: "text",
          text: result,
        },
      ],
    };
  }
);

const getCaseStudy = server.tool(
  "get-case-study",
  "Retrieve EY case studies by industry and solution type",
  {
    industry: z.string().describe("Client industry sector"),
    solution_type: z.string().optional().describe("Type of solution implemented")
  },
  async (params: { industry: string; solution_type?: string }) => {
    const industry = params.industry || "";
    const solution_type = params.solution_type || "";
    
    const caseStudies: any = {
      "financial services": "Global Bank Digital Transformation - Reduced processing time by 60% through automated workflows, implemented real-time fraud detection, and enhanced customer experience with mobile-first solutions.",
      "healthcare": "Healthcare Provider Analytics Implementation - Improved patient outcomes by 25% using predictive analytics, streamlined operations, and integrated electronic health records across 50+ locations.",
      "retail": "Retail Chain Omnichannel Strategy - Increased revenue by 40% through unified customer experience, inventory optimization, and personalized marketing campaigns.",
      "manufacturing": "Smart Factory Implementation - Achieved 30% efficiency gains through IoT sensors, predictive maintenance, and automated quality control systems."
    };
    
    let result = "No case study found";
    
    if (industry && industry.trim() !== "") {
      const industryLower = industry.toLowerCase().trim();
      if (caseStudies[industryLower]) {
        result = caseStudies[industryLower];
        if (solution_type && solution_type.trim() !== "") {
          result = result + " (Solution type: " + solution_type + ")";
        }
      } else {
        const availableIndustries = Object.keys(caseStudies);
        result = `Industry "${industry}" not found. Available industries: ${availableIndustries.join(', ')}`;
      }
    } else {
      const availableIndustries = Object.keys(caseStudies);
      result = `Please provide an industry. Available industries: ${availableIndustries.join(', ')}`;
    }
    
    return {
      content: [
        {
          type: "text",
          text: result,
        },
      ],
    };
  }
);

const findTemplate = server.tool(
  "find-template",
  "Find EY engagement templates and documents",
  {
    engagement_type: z.string().describe("Type of engagement (audit, advisory, tax, consulting)"),
    document_type: z.string().optional().describe("Template type needed")
  },
  async (params: { engagement_type: string; document_type?: string }) => {
    const engagement_type = params.engagement_type || "";
    const document_type = params.document_type || "";
    
    const templates: any = {
      "audit": "EY Standard Audit Program Template - Comprehensive audit procedures, risk assessment workbooks, testing matrices, and compliance checklists for financial statement audits.",
      "advisory": "EY Business Case Template - ROI analysis framework, stakeholder assessment tools, implementation roadmaps, and change management guides for transformation projects.",
      "tax": "EY Tax Compliance Templates - Filing checklists, documentation requirements, transfer pricing studies, and international tax planning frameworks.",
      "consulting": "EY Strategy Engagement Templates - Market analysis frameworks, competitive assessment tools, business model design templates, and performance measurement dashboards."
    };
    
    let result = "No template found";
    
    if (engagement_type && engagement_type.trim() !== "") {
      const engagementLower = engagement_type.toLowerCase().trim();
      if (templates[engagementLower]) {
        result = templates[engagementLower];
        if (document_type && document_type.trim() !== "") {
          result = result + " (Document type: " + document_type + ")";
        }
      } else {
        const availableTypes = Object.keys(templates);
        result = `Engagement type "${engagement_type}" not found. Available types: ${availableTypes.join(', ')}`;
      }
    } else {
      const availableTypes = Object.keys(templates);
      result = `Please provide an engagement type. Available types: ${availableTypes.join(', ')}`;
    }
    
    return {
      content: [
        {
          type: "text",
          text: result,
        },
      ],
    };
  }
);

const app = express();
app.use(express.json());

const transport: StreamableHTTPServerTransport =
  new StreamableHTTPServerTransport({
    sessionIdGenerator: undefined, // set to undefined for stateless servers
  });

// Setup routes for the server
const setupServer = async () => {
  await server.connect(transport);
};

app.post("/mcp", async (req: Request, res: Response) => {
  console.log("Received MCP request:", req.body);
  try {
    await transport.handleRequest(req, res, req.body);
  } catch (error) {
    console.error("Error handling MCP request:", error);
    if (!res.headersSent) {
      res.status(500).json({
        jsonrpc: "2.0",
        error: {
          code: -32603,
          message: "Internal server error",
        },
        id: null,
      });
    }
  }
});

app.get("/mcp", async (req: Request, res: Response) => {
  console.log("Received GET MCP request");
  res.writeHead(405).end(
    JSON.stringify({
      jsonrpc: "2.0",
      error: {
        code: -32000,
        message: "Method not allowed.",
      },
      id: null,
    })
  );
});

app.delete("/mcp", async (req: Request, res: Response) => {
  console.log("Received DELETE MCP request");
  res.writeHead(405).end(
    JSON.stringify({
      jsonrpc: "2.0",
      error: {
        code: -32000,
        message: "Method not allowed.",
      },
      id: null,
    })
  );
});

// Start the server
const PORT = process.env.PORT || 3000;
setupServer()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`MCP Streamable HTTP Server listening on port ${PORT}`);
    });
  })
  .catch((error) => {
    console.error("Failed to set up the server:", error);
    process.exit(1);
  });